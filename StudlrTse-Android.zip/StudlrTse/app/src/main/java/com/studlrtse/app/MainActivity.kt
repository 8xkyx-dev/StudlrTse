package com.studlrtse.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private val Navy = Color(0xFF080E1B)
private val Panel = Color(0xFF111E32)
private val Panel2 = Color(0xFF172944)
private val Blue = Color(0xFF258BFF)
private val Cyan = Color(0xFF63C8FF)
private val Muted = Color(0xFF9CB0CC)
private val White = Color(0xFFF3F7FF)
private val Green = Color(0xFF39D98A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { StudlrTseApp() }
    }
}

data class QuizQuestion(val question: String, val options: List<String>, val answerIndex: Int, val explanation: String)
data class StudyProject(
    val id: String,
    var title: String,
    val originalName: String,
    val mimeType: String,
    val importedAt: Long,
    var summary: String = "",
    var keyDetails: List<String> = emptyList(),
    var quiz: List<QuizQuestion> = emptyList(),
    var flashcards: List<Pair<String, String>> = emptyList(),
    var offline: Boolean = false,
    var lastStudied: Long = 0L
)

class ProjectStore(private val context: Context) {
    private val root = File(context.filesDir, "studlrtse/projects").apply { mkdirs() }
    private val offlineRoot = File(context.filesDir, "studlrtse/offline").apply { mkdirs() }
    private val index = File(context.filesDir, "studlrtse/projects.json")

    fun load(): MutableList<StudyProject> {
        if (!index.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(index.readText())
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val qArr = o.optJSONArray("quiz") ?: JSONArray()
                val fArr = o.optJSONArray("flashcards") ?: JSONArray()
                StudyProject(
                    id = o.getString("id"), title = o.getString("title"), originalName = o.getString("originalName"),
                    mimeType = o.optString("mimeType"), importedAt = o.optLong("importedAt"),
                    summary = o.optString("summary"), keyDetails = jsonStrings(o.optJSONArray("keyDetails")),
                    quiz = MutableList(qArr.length()) { j ->
                        val q = qArr.getJSONObject(j)
                        QuizQuestion(q.optString("question"), jsonStrings(q.optJSONArray("options")), q.optInt("answerIndex"), q.optString("explanation"))
                    },
                    flashcards = MutableList(fArr.length()) { j -> val f = fArr.getJSONObject(j); f.optString("front") to f.optString("back") },
                    offline = o.optBoolean("offline"), lastStudied = o.optLong("lastStudied")
                )
            }
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(projects: List<StudyProject>) {
        val arr = JSONArray()
        projects.forEach { p ->
            val q = JSONArray(); p.quiz.forEach { item -> q.put(JSONObject().put("question", item.question).put("options", JSONArray(item.options)).put("answerIndex", item.answerIndex).put("explanation", item.explanation)) }
            val f = JSONArray(); p.flashcards.forEach { item -> f.put(JSONObject().put("front", item.first).put("back", item.second)) }
            arr.put(JSONObject().put("id", p.id).put("title", p.title).put("originalName", p.originalName).put("mimeType", p.mimeType)
                .put("importedAt", p.importedAt).put("summary", p.summary).put("keyDetails", JSONArray(p.keyDetails))
                .put("quiz", q).put("flashcards", f).put("offline", p.offline).put("lastStudied", p.lastStudied))
        }
        index.writeText(arr.toString())
    }

    fun content(project: StudyProject): String = File(File(root, project.id), "content.txt").let { if (it.exists()) it.readText() else "" }
    fun sourceFile(project: StudyProject): File? = File(root, project.id).listFiles()?.firstOrNull { it.name.startsWith("source.") }

    fun importDocument(context: Context, uri: Uri): StudyProject {
        val name = queryName(context, uri) ?: "Study material ${DateFormat.getDateInstance().format(Date())}"
        val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
        val ext = if (name.contains('.')) name.substringAfterLast('.').lowercase().replace(Regex("[^a-z0-9]"), "") else when {
            mime.contains("pdf") -> "pdf"
            mime.contains("wordprocessingml") -> "docx"
            mime.contains("presentationml") -> "pptx"
            mime.contains("markdown") -> "md"
            mime.startsWith("text/") -> "txt"
            else -> "txt"
        }
        val id = UUID.randomUUID().toString()
        val folder = File(root, id).apply { mkdirs() }
        val source = File(folder, "source.$ext")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to open this file." }
            FileOutputStream(source).use { output -> input.copyTo(output) }
        }
        try {
            val extracted = extractText(source, ext, mime)
            if (extracted.isBlank()) throw IllegalArgumentException("No readable text was found. Scanned PDFs and image-only files need OCR, which is not included yet.")
            File(folder, "content.txt").writeText(extracted)
            return StudyProject(id, name.substringBeforeLast('.', name), name, mime, System.currentTimeMillis())
        } catch (e: Exception) {
            folder.deleteRecursively()
            throw e
        }
    }

    fun rename(project: StudyProject, newName: String) { project.title = newName.trim() }
    fun delete(project: StudyProject) { File(root, project.id).deleteRecursively(); File(offlineRoot, "${project.id}.zip").delete() }

    fun downloadOffline(project: StudyProject): Long {
        val folder = File(root, project.id)
        val target = File(offlineRoot, "${project.id}.zip")
        ZipOutputStream(FileOutputStream(target)).use { zip ->
            folder.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(folder).invariantSeparatorsPath
                zip.putNextEntry(ZipEntry(relative)); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
            }
            val quiz = JSONArray(); project.quiz.forEach { q -> quiz.put(JSONObject().put("question", q.question).put("options", JSONArray(q.options)).put("answerIndex", q.answerIndex).put("explanation", q.explanation)) }
            val flashcards = JSONArray(); project.flashcards.forEach { f -> flashcards.put(JSONObject().put("front", f.first).put("back", f.second)) }
            val metadata = JSONObject().put("title", project.title).put("originalName", project.originalName).put("summary", project.summary)
                .put("keyDetails", JSONArray(project.keyDetails)).put("quiz", quiz).put("flashcards", flashcards).toString().toByteArray()
            zip.putNextEntry(ZipEntry("project.json")); zip.write(metadata); zip.closeEntry()
        }
        project.offline = true
        return target.length()
    }

    fun removeOffline(project: StudyProject) { File(offlineRoot, "${project.id}.zip").delete(); project.offline = false }
    fun offlineSize(): Long = offlineRoot.listFiles()?.sumOf { it.length() } ?: 0L

    private fun queryName(context: Context, uri: Uri): String? {
        return try { context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } } catch (_: Exception) { null }
    }

    private fun extractText(file: File, ext: String, mime: String): String {
        return when {
            ext == "pdf" || mime == "application/pdf" -> PDDocument.load(file).use { PDFTextStripper().getText(it) }
            ext == "docx" || ext == "pptx" -> extractOfficeXml(file, ext)
            ext in listOf("txt", "md", "csv", "html", "htm") -> file.readText(Charsets.UTF_8).let { if (ext == "html" || ext == "htm") it.replace(Regex("<[^>]*>"), " ") else it }
            else -> throw IllegalArgumentException("Unsupported file type. Please import PDF, DOCX, PPTX, TXT, MD or CSV.")
        }.take(1_500_000)
    }

    private fun extractOfficeXml(file: File, ext: String): String {
        val out = StringBuilder()
        ZipInputStream(file.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val relevant = if (ext == "docx") entry.name == "word/document.xml" else entry.name.matches(Regex("ppt/slides/slide[0-9]+\\.xml"))
                if (relevant) {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    val pieces = Regex("<(?:w:t|a:t)[^>]*>(.*?)</(?:w:t|a:t)>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
                    pieces.forEach { out.append(it.groupValues[1].replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")).append(' ') }
                }
                zip.closeEntry(); entry = zip.nextEntry
            }
        }
        return out.toString()
    }

    private fun jsonStrings(arr: JSONArray?): List<String> = if (arr == null) emptyList() else MutableList(arr.length()) { arr.optString(it) }
}

class OpenRouterClient(private val context: Context) {
    private val prefs = context.getSharedPreferences("studlrtse_settings", Context.MODE_PRIVATE)
    fun apiKey() = prefs.getString("api_key", "") ?: ""
    fun model() = prefs.getString("model", "openrouter/free") ?: "openrouter/free"
    fun save(key: String, model: String) { prefs.edit().putString("api_key", key.trim()).putString("model", model.trim().ifBlank { "openrouter/free" }).apply() }

    suspend fun generate(prompt: String): String = withContext(Dispatchers.IO) {
        val key = apiKey()
        require(key.isNotBlank()) { "Add your OpenRouter API key in Settings first." }
        val conn = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 25000; readTimeout = 60000; doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("HTTP-Referer", "https://studlrtse.app")
            setRequestProperty("X-Title", "StudlrTse")
        }
        val body = JSONObject().put("model", model()).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt))).put("temperature", 0.35).toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw IllegalStateException("AI provider error ${conn.responseCode}: ${JSONObject(response).optJSONObject("error")?.optString("message") ?: response.take(300)}")
        JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudlrTseApp() {
    val context = LocalContext.current
    val store = remember { ProjectStore(context) }
    val ai = remember { OpenRouterClient(context) }
    val projects = remember { mutableStateListOf<StudyProject>().apply { addAll(store.load()) } }
    var page by remember { mutableStateOf("Home") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<StudyProject?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<StudyProject?>(null) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableIntStateOf(-1) }
    var showAnswer by remember { mutableStateOf(false) }
    var tutorQuestion by remember { mutableStateOf("") }
    var tutorAnswer by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf(ai.apiKey()) }
    var model by remember { mutableStateOf(ai.model()) }
    val scope = rememberCoroutineScope()
    val selected = projects.firstOrNull { it.id == selectedId }

    fun persist() { store.save(projects.toList()) }
    fun notify(text: String) { message = text }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                try {
                    val project = withContext(Dispatchers.IO) { store.importDocument(context, uri) }
                    projects.add(0, project); persist(); selectedId = project.id; page = "Project"
                    notify("Project imported and saved on this device.")
                } catch (e: Exception) { notify(e.message ?: "Import failed.") }
                busy = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Cyan, background = Navy, surface = Panel, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(
                title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoStories, null, tint = Cyan); Spacer(Modifier.width(9.dp)); Text(if (page == "Project") selected?.title ?: "Project" else "StudlrTse", fontWeight = FontWeight.Bold) } },
                navigationIcon = { if (page == "Project") IconButton(onClick = { selectedId = null; page = "Projects" }) { Icon(Icons.Default.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = White, navigationIconContentColor = White),
                actions = { if (page == "Project" && selected != null) IconButton(onClick = { renameTarget = selected; renameValue = selected.title }) { Icon(Icons.Default.Edit, "Rename project") } }
            )
        }, bottomBar = {
            NavigationBar(containerColor = Panel) {
                val navs = listOf("Home" to Icons.Default.Home, "Projects" to Icons.Default.Folder, "Offline" to Icons.Default.CloudDownload, "Practice" to Icons.Default.Psychology, "Settings" to Icons.Default.Settings)
                navs.forEach { (name, icon) -> NavigationBarItem(selected = page == name || (page == "Project" && name == "Projects"), onClick = { selectedId = null; page = name }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted)) }
            }
        }, snackbarHost = { SnackbarHost(hostState = remember { SnackbarHostState() }) }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    "Home" -> HomeScreen(projects, onImport = { picker.launch(arrayOf("*/*")) }, onProject = { selectedId = it.id; page = "Project" }, onNavigate = { page = it }, onQuickQuiz = { val p = projects.firstOrNull { it.quiz.isNotEmpty() }; if (p != null) { selectedId = p.id; page = "Project" } else notify("Generate a quiz from a project first.") })
                    "Projects" -> ProjectsScreen(projects, search, { search = it }, onProject = { selectedId = it.id; page = "Project" }, onRename = { renameTarget = it; renameValue = it.title }, onDelete = { deleteTarget = it }, onImport = { picker.launch(arrayOf("*/*")) })
                    "Offline" -> OfflineScreen(projects, store.offlineSize(), onOpen = { selectedId = it.id; page = "Project" }, onRemove = { store.removeOffline(it); persist(); notify("Offline package removed. Your project remains in the library.") })
                    "Practice" -> PracticeScreen(projects, onProject = { selectedId = it.id; page = "Project" })
                    "Settings" -> SettingsScreen(apiKey, { apiKey = it }, model, { model = it }, onSave = { ai.save(apiKey, model); notify("AI settings saved on this device.") })
                    "Project" -> if (selected != null) ProjectScreen(selected, store.content(selected), busy, onGenerateSummary = {
                        busy = true; scope.launch { try {
                            val raw = ai.generate("You are a careful academic study assistant. Use ONLY the supplied study material. Return valid JSON only with keys summary (string), keyDetails (array of 5-12 concise strings), flashcards (array of objects with front and back). Do not invent facts. If unclear, say so.\n\nMATERIAL:\n${store.content(selected).take(18000)}")
                            val json = parseJsonObject(raw); selected.summary = json.optString("summary"); selected.keyDetails = jsonArrayStrings(json.optJSONArray("keyDetails")); val fs = json.optJSONArray("flashcards") ?: JSONArray(); selected.flashcards = MutableList(fs.length()) { i -> val f = fs.getJSONObject(i); f.optString("front") to f.optString("back") }; selected.lastStudied = System.currentTimeMillis(); persist(); notify("Summary and revision resources generated.")
                        } catch (e: Exception) { notify(e.message ?: "Could not generate summary.") }; busy = false }
                    }, onGenerateQuiz = {
                        busy = true; scope.launch { try {
                            val raw = ai.generate("Create 8 educational multiple-choice quiz questions based strictly on this study material. Return valid JSON only as {\"questions\":[{\"question\":\"...\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"answerIndex\":0,\"explanation\":\"...\"}]}. answerIndex is zero-based. Ensure one correct answer.\n\nMATERIAL:\n${store.content(selected).take(18000)}")
                            val arr = parseJsonObject(raw).optJSONArray("questions") ?: throw IllegalStateException("The AI response did not contain quiz questions.")
                            selected.quiz = MutableList(arr.length()) { i -> val q = arr.getJSONObject(i); QuizQuestion(q.optString("question"), jsonArrayStrings(q.optJSONArray("options")), q.optInt("answerIndex"), q.optString("explanation")) }.filter { it.options.size >= 2 }
                            quizIndex = 0; selectedAnswer = -1; showAnswer = false; persist(); notify("${selected.quiz.size} quiz questions generated.")
                        } catch (e: Exception) { notify(e.message ?: "Could not generate quiz.") }; busy = false }
                    }, onDownload = { try { val bytes = store.downloadOffline(selected); persist(); notify("Offline project package saved (${formatBytes(bytes)}).") } catch (e: Exception) { notify(e.message ?: "Offline download failed.") } }, onRemoveOffline = { store.removeOffline(selected); persist(); notify("Offline copy removed; your project is still saved.") }, quizIndex = quizIndex, onQuizIndex = { quizIndex = it; selectedAnswer = -1; showAnswer = false }, selectedAnswer = selectedAnswer, onAnswer = { selectedAnswer = it }, showAnswer = showAnswer, onReveal = { showAnswer = true }, tutorQuestion = tutorQuestion, onTutorQuestion = { tutorQuestion = it }, tutorAnswer = tutorAnswer, onAskTutor = {
                        val question = tutorQuestion.trim(); if (question.isNotEmpty()) { busy = true; scope.launch { try { tutorAnswer = ai.generate("Answer the student's question using the provided study material as the primary source. If the answer is not in the material, say so clearly and separate any general explanation.\nQUESTION: $question\n\nMATERIAL:\n${store.content(selected).take(16000)}") } catch (e: Exception) { tutorAnswer = e.message ?: "Unable to contact the AI provider." }; busy = false } }
                    }) else EmptyState("Choose a project from your library.")
                }
                if (busy) Box(Modifier.fillMaxSize().background(Color(0x66000000)), contentAlignment = Alignment.Center) { Card(colors = CardDefaults.cardColors(containerColor = Panel2)) { Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(color = Cyan, modifier = Modifier.size(24.dp), strokeWidth = 2.dp); Spacer(Modifier.width(12.dp)); Text("Working on it…") } } }
                if (message.isNotBlank()) LaunchedEffect(message) { kotlinx.coroutines.delay(3500); message = "" }
                if (message.isNotBlank()) Surface(Modifier.align(Alignment.BottomCenter).padding(12.dp), color = Panel2, shape = RoundedCornerShape(14.dp), shadowElevation = 8.dp) { Text(message, Modifier.padding(14.dp), color = White, fontSize = 13.sp) }
            }
        }
    }

    if (renameTarget != null) AlertDialog(onDismissRequest = { renameTarget = null }, title = { Text("Rename project") }, text = { OutlinedTextField(renameValue, { renameValue = it }, singleLine = true, label = { Text("Project name") }) }, confirmButton = { TextButton(onClick = { val p = renameTarget!!; if (renameValue.isNotBlank()) { store.rename(p, renameValue); persist(); notify("Project renamed.") }; renameTarget = null }) { Text("Save") } }, dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } }, containerColor = Panel)
    if (deleteTarget != null) AlertDialog(onDismissRequest = { deleteTarget = null }, title = { Text("Delete project?") }, text = { Text("This permanently removes ${deleteTarget!!.title} and its local files from this device.") }, confirmButton = { TextButton(onClick = { store.delete(deleteTarget!!); projects.remove(deleteTarget); persist(); deleteTarget = null; selectedId = null; page = "Projects" }) { Text("Delete", color = Color.Red) } }, dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }, containerColor = Panel)
}

@Composable
fun HomeScreen(projects: List<StudyProject>, onImport: () -> Unit, onProject: (StudyProject) -> Unit, onNavigate: (String) -> Unit, onQuickQuiz: () -> Unit) {
    val quizzes = projects.sumOf { it.quiz.size }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Spacer(Modifier.height(6.dp)); Column {
            Text("YOUR PERSONAL LEARNING UNIVERSE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text("Good ${greeting()}.", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Ready to make some progress?", color = Muted, fontSize = 14.sp)
        } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("${projects.size}", "Projects", Icons.Default.Folder, Modifier.weight(1f))
            StatCard("$quizzes", "Saved questions", Icons.Default.Quiz, Modifier.weight(1f))
            StatCard("${projects.count { it.offline }}", "Offline", Icons.Default.CloudDone, Modifier.weight(1f))
        } }
        item { SectionTitle("Continue learning", "See all") { onNavigate("Projects") } }
        if (projects.isEmpty()) item { EmptyState("Your study space is ready. Import your first document to create a project.") }
        else items(projects.sortedByDescending { it.lastStudied }.take(1), key = { "continue-${it.id}" }) { ProjectCard(it, { onProject(it) }, {}, {}, compact = true) }
        item { SectionTitle("Quick actions") }
        item { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Import document", "From Drive or phone", Icons.Default.CloudUpload, Modifier.weight(1f), onImport)
                ActionCard("New project", "Start with a file", Icons.Default.CreateNewFolder, Modifier.weight(1f), onImport)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Quick quiz", "Test your knowledge", Icons.Default.Psychology, Modifier.weight(1f), onQuickQuiz)
                ActionCard("Offline projects", "Study without Wi-Fi", Icons.Default.CloudDownload, Modifier.weight(1f)) { onNavigate("Offline") }
            }
        } }
        item { SectionTitle("My projects", "View all") { onNavigate("Projects") } }
        items(projects.take(5), key = { "home-${it.id}" }) { ProjectCard(it, { onProject(it) }, {}, {}, compact = true) }
    }
}

@Composable
fun ProjectsScreen(projects: List<StudyProject>, search: String, onSearch: (String) -> Unit, onProject: (StudyProject) -> Unit, onRename: (StudyProject) -> Unit, onDelete: (StudyProject) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(8.dp)); Text("My Projects", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Every document becomes its own study space.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth(), placeholder = { Text("Search projects…", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(12.dp))
        if (projects.isEmpty()) EmptyState("No projects yet. Import a PDF, Word document, PowerPoint, text or Markdown file.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(projects.filter { it.title.contains(search, true) || it.originalName.contains(search, true) }, key = { it.id }) { p -> ProjectCard(p, { onProject(p) }, { onRename(p) }, { onDelete(p) }) }
        }
    }
}

@Composable
fun OfflineScreen(projects: List<StudyProject>, bytes: Long, onOpen: (StudyProject) -> Unit, onRemove: (StudyProject) -> Unit) {
    val offline = projects.filter { it.offline }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Offline projects", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your downloaded study spaces, ready without an internet connection.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CloudDone, null, tint = Green); Spacer(Modifier.width(9.dp)); Text("Offline storage", fontWeight = FontWeight.SemiBold) }; Text(formatBytes(bytes), color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Total downloaded project package size", color = Muted, fontSize = 12.sp) } }
        Spacer(Modifier.height(14.dp))
        if (offline.isEmpty()) EmptyState("You haven't downloaded any project packages yet. Open a project and choose Download for offline.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(offline, key = { it.id }) { p -> ProjectCard(p, { onOpen(p) }, {}, { onRemove(p) }, compact = false, actionLabel = "Remove offline") } }
    }
}

@Composable
fun PracticeScreen(projects: List<StudyProject>, onProject: (StudyProject) -> Unit) {
    val withQuiz = projects.filter { it.quiz.isNotEmpty() }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Practice", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Pick a project and keep your knowledge active.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        if (withQuiz.isEmpty()) EmptyState("Your quiz library is empty. Open a project, generate a quiz, and it will appear here.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(withQuiz, key = { it.id }) { p -> Card(Modifier.fillMaxWidth().clickable { onProject(p) }, colors = CardDefaults.cardColors(containerColor = Panel)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Quiz, null, tint = Cyan); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(p.title, fontWeight = FontWeight.SemiBold); Text("${p.quiz.size} questions · ${if (p.offline) "Available offline" else "Saved locally"}", color = Muted, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } } } }
    }
}

@Composable
fun ProjectScreen(project: StudyProject, content: String, busy: Boolean, onGenerateSummary: () -> Unit, onGenerateQuiz: () -> Unit, onDownload: () -> Unit, onRemoveOffline: () -> Unit, quizIndex: Int, onQuizIndex: (Int) -> Unit, selectedAnswer: Int, onAnswer: (Int) -> Unit, showAnswer: Boolean, onReveal: () -> Unit, tutorQuestion: String, onTutorQuestion: (String) -> Unit, tutorAnswer: String, onAskTutor: () -> Unit) {
    var tab by remember(project.id) { mutableStateOf("Overview") }
    var flashIndex by remember(project.id) { mutableIntStateOf(0) }
    var revealFlash by remember(project.id) { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Spacer(Modifier.height(4.dp)); Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Blue, Panel2))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Description, null, tint = White, modifier = Modifier.size(27.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(project.title, color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("${project.originalName} · ${formatDate(project.importedAt)}", color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }; if (project.offline) Icon(Icons.Default.CloudDone, null, tint = Green) }
            Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { if (project.offline) BadgePill("Available offline", Green) else BadgePill("Saved on device", Cyan); BadgePill("${formatBytes(storeSize(content))} text", Muted) }
            Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = if (project.offline) onRemoveOffline else onDownload, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (project.offline) Panel2 else Blue)) { Icon(if (project.offline) Icons.Default.CloudOff else Icons.Default.Download, null); Spacer(Modifier.width(5.dp)); Text(if (project.offline) "Remove offline" else "Download offline", fontSize = 11.sp) } }
        } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("Overview", "Summary", "Quiz", "Flashcards", "Tutor", "Source").forEach { label -> FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label, fontSize = 11.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Panel2, selectedLabelColor = Cyan)) } } }
        when (tab) {
            "Overview" -> {
                item { SectionTitle("Project overview") }
                item { InfoCard("Original document", project.originalName + "\n" + project.mimeType) }
                item { InfoCard("Study resources", "${if (project.summary.isNotBlank()) "Summary ready" else "No summary yet"} · ${project.quiz.size} quiz questions · ${project.flashcards.size} flashcards") }
                item { Text("Source preview", color = White, fontWeight = FontWeight.Bold) }
                item { InfoCard("Extracted content", content.take(1000).ifBlank { "No extracted text available." } + if (content.length > 1000) "…" else "") }
            }
            "Summary" -> {
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Key details & summary", Modifier.weight(1f), color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }; Button(onClick = onGenerateSummary, enabled = !busy) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(5.dp)); Text(if (project.summary.isBlank()) "Generate" else "Regenerate") } }
                if (project.summary.isBlank()) item { EmptyState("Generate a structured summary and key details from this document. AI generation requires an API key and internet connection.") }
                else { item { InfoCard("Summary", project.summary) }; item { SectionTitle("Key details") }; items(project.keyDetails) { detail -> InfoCard("•", detail) } }
            }
            "Quiz" -> {
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Project quiz", Modifier.weight(1f), color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }; Button(onClick = onGenerateQuiz, enabled = !busy) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(5.dp)); Text("Generate quiz") } }
                if (project.quiz.isEmpty()) item { EmptyState("Generate a quiz based on this document. Questions and explanations will be saved with the project for offline practice.") }
                else {
                    val q = project.quiz[quizIndex.coerceIn(0, project.quiz.lastIndex)]
                    item { LinearProgressIndicator(progress = { (quizIndex + 1f) / project.quiz.size }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Panel2) }
                    item { Text("Question ${quizIndex + 1} of ${project.quiz.size}", color = Muted, fontSize = 12.sp) }
                    item { InfoCard("Question", q.question) }
                    items(q.options.size) { index -> val isCorrect = index == q.answerIndex; val chosen = selectedAnswer == index; Card(Modifier.fillMaxWidth().clickable(enabled = !showAnswer) { onAnswer(index) }, colors = CardDefaults.cardColors(containerColor = when { showAnswer && isCorrect -> Color(0xFF123A32); chosen -> Panel2; else -> Panel }), border = if (chosen || (showAnswer && isCorrect)) androidx.compose.foundation.BorderStroke(1.dp, if (isCorrect) Green else Cyan) else null) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text("${'A' + index}.", color = Cyan, fontWeight = FontWeight.Bold); Spacer(Modifier.width(10.dp)); Text(q.options[index], Modifier.weight(1f)); if (showAnswer && isCorrect) Icon(Icons.Default.CheckCircle, null, tint = Green) } } }
                    if (showAnswer) item { InfoCard("Explanation", q.explanation) }
                    item { Button(onClick = { if (!showAnswer) onReveal() else onQuizIndex((quizIndex + 1) % project.quiz.size) }, enabled = selectedAnswer >= 0 || showAnswer, modifier = Modifier.fillMaxWidth()) { Text(if (showAnswer) "Next question" else "Check answer") } }
                }
            }
            "Flashcards" -> {
                item { Text("Flashcards", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                if (project.flashcards.isEmpty()) item { EmptyState("Generate a summary first. StudlrTse will create flashcards from the key concepts.") }
                else { val card = project.flashcards[flashIndex.coerceIn(0, project.flashcards.lastIndex)]; item { Card(Modifier.fillMaxWidth().heightIn(min = 190.dp).clickable { revealFlash = !revealFlash }, colors = CardDefaults.cardColors(containerColor = Panel2)) { Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text(if (revealFlash) "ANSWER" else "QUESTION", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(14.dp)); Text(if (revealFlash) card.second else card.first, color = White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(14.dp)); Text("Tap card to flip", color = Muted, fontSize = 11.sp) } } }; item { Button(onClick = { flashIndex = (flashIndex + 1) % project.flashcards.size; revealFlash = false }, modifier = Modifier.fillMaxWidth()) { Text("Next flashcard") } } }
            }
            "Tutor" -> {
                item { Text("Ask this document", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                item { OutlinedTextField(tutorQuestion, onTutorQuestion, Modifier.fillMaxWidth(), label = { Text("Ask a question about this material") }, minLines = 3) }
                item { Button(onClick = onAskTutor, enabled = tutorQuestion.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("Ask AI tutor") } }
                if (tutorAnswer.isNotBlank()) item { InfoCard("Tutor response", tutorAnswer) }
            }
            "Source" -> { item { InfoCard("Original filename", project.originalName) }; item { InfoCard("Extracted text", content.take(12000)) } }
        }
    }
}

@Composable
fun SettingsScreen(apiKey: String, onKey: (String) -> Unit, model: String, onModel: (String) -> Unit, onSave: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("Settings", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Choose your AI connection. Your projects remain stored locally regardless of provider.", color = Muted, fontSize = 13.sp)
        InfoCard("AI provider", "OpenRouter API · Compatible with multiple model providers. You supply your own API key; free model availability and quotas depend on OpenRouter and the selected model.")
        OutlinedTextField(apiKey, onKey, Modifier.fillMaxWidth(), label = { Text("OpenRouter API key") }, placeholder = { Text("sk-or-…") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, onModel, Modifier.fillMaxWidth(), label = { Text("Model ID") }, supportingText = { Text("Default: openrouter/free. You can change this to another model available to your account.") })
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save AI settings") }
        InfoCard("Privacy & storage", "Imported documents and generated resources are stored in this app's private storage. The API key is stored in app-private preferences in this starter; before wider distribution, replace this with Android Keystore-backed encryption. AI requests send relevant document text to the provider you configure.")
        InfoCard("Supported imports", "PDF (selectable text), DOCX, PPTX, TXT, Markdown and CSV. Scanned PDFs need OCR, which is not included in this build.")
        InfoCard("Offline access", "Projects and generated resources are saved locally. Download for offline creates a portable ZIP package and marks the project as offline-ready. New AI generation still needs internet.")
        InfoCard("About", "StudlrTse · Version 1.0.0 · Kotlin + Jetpack Compose")
    }
}

@Composable
fun ProjectCard(p: StudyProject, onOpen: () -> Unit, onRename: () -> Unit, onMore: () -> Unit, compact: Boolean = false, actionLabel: String = "More") {
    Card(Modifier.fillMaxWidth().clickable { onOpen() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Blue.copy(alpha = .35f), Panel2))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Description, null, tint = Cyan, modifier = Modifier.size(25.dp)) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(p.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${p.originalName} · ${formatDate(p.importedAt)}", color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { if (p.offline) BadgePill("Offline", Green); if (p.summary.isNotBlank()) BadgePill("Summary", Cyan); if (p.quiz.isNotEmpty()) BadgePill("${p.quiz.size} Qs", Blue) }
            }
            if (!compact) IconButton(onClick = onRename) { Icon(Icons.Default.Edit, "Rename", tint = Muted) }
            IconButton(onClick = onMore) { Icon(if (actionLabel == "Remove offline") Icons.Default.CloudOff else Icons.Default.MoreVert, actionLabel, tint = Muted) }
        }
    }
}

@Composable
fun StatCard(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) { Column(Modifier.padding(12.dp)) { Icon(icon, null, tint = Cyan); Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text(label, color = Muted, fontSize = 10.sp) } }
}

@Composable
fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) { Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(24.dp)); Spacer(Modifier.height(8.dp)); Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) } }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(15.dp)) { Text(title, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text(body, color = White, fontSize = 13.sp, lineHeight = 19.sp) } }
}

@Composable
fun BadgePill(text: String, color: Color) { Surface(color = color.copy(alpha = .14f), shape = CircleShape) { Text(text, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold) } }

@Composable
fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold); if (action != null && onAction != null) Text(action, Modifier.clickable { onAction() }, color = Cyan, fontSize = 12.sp) } }

@Composable
fun EmptyState(text: String) { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.AutoStories, null, tint = Cyan, modifier = Modifier.size(34.dp)); Spacer(Modifier.height(10.dp)); Text(text, color = Muted, fontSize = 13.sp, lineHeight = 19.sp) } } }

private fun greeting() = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) { in 5..11 -> "morning"; in 12..16 -> "afternoon"; else -> "evening" }
private fun formatDate(time: Long) = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(time))
private fun formatBytes(bytes: Long): String = if (bytes < 1024) "$bytes B" else if (bytes < 1024 * 1024) "%.1f KB".format(bytes / 1024f) else "%.1f MB".format(bytes / (1024f * 1024f))
private fun storeSize(content: String) = content.toByteArray().size.toLong()
private fun jsonArrayStrings(arr: JSONArray?): List<String> = if (arr == null) emptyList() else MutableList(arr.length()) { arr.optString(it) }
private fun parseJsonObject(raw: String): JSONObject {
    val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    val start = cleaned.indexOf('{'); val end = cleaned.lastIndexOf('}')
    if (start < 0 || end <= start) throw IllegalStateException("The AI returned an unexpected response. Try again.")
    return JSONObject(cleaned.substring(start, end + 1))
}
