# StudlrTse icon assets

- `app/src/main/res/drawable/ic_studlrtse.xml` is the actual vector launcher icon referenced by AndroidManifest.xml.
- `app-icon.png` and `StudlrTse-Icon-512.png` are high-resolution visual assets for project branding, repository artwork, and future store graphics.

The launcher icon is a custom open-book and graduation-cap mark in icy blue on deep navy.
