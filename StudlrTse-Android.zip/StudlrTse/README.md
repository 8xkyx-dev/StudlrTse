# StudlrTse — Android study workspace

**Tagline:** Your personal learning universe.

StudlrTse is a personal-use Android study app built with Kotlin and Jetpack Compose. It turns imported course documents into local study projects with AI-assisted summaries, key details, quizzes, flashcards and a document-grounded tutor.

## Included in this starter

- Premium navy / black / icy-blue interface and custom vector launcher icon.
- Import from Android's system document picker. Google Drive can appear as a source when its Android document provider is installed and signed in.
- Supported text extraction: selectable-text PDF, DOCX, PPTX, TXT, Markdown, CSV, and basic HTML.
- Each imported file becomes a project with an editable project title and preserved original filename.
- Project resources (summary, key details, quiz questions and flashcards) are saved locally.
- Project-specific offline package download: creates a ZIP containing the source document, extracted text and project metadata. The project and generated resources remain locally accessible even without an AI connection.
- Offline Projects screen and remove-offline-package action.
- OpenRouter-compatible AI endpoint. The default model setting is `openrouter/free`; choose a model currently available to your OpenRouter account.
- GitHub Actions workflow builds a debug APK.

## Important implementation notes

1. Importing copies the selected file into the app's private storage. This means imported projects and their saved resources can be opened offline after import. The **Download offline** action additionally creates a portable project ZIP under the app's private offline directory and marks it in the Offline list.
2. The app does not silently edit or rename the original Drive file. Rename changes the local StudlrTse project title only.
3. New AI generation and tutor requests require an internet connection and a configured API key. Existing summaries, quizzes and flashcards are local.
4. PDF text extraction only works when text is selectable. Scanned PDFs require OCR, not included here.
5. Google Drive is accessed through Android's system file picker (Storage Access Framework). This is not full Drive API browsing/sync; the picker lists Drive if the Drive app/provider is available.
6. API keys are currently stored in app-private SharedPreferences. This is acceptable only as an initial personal-use starter; before wider distribution, move secrets to Android Keystore-backed encrypted storage. Never commit a key to GitHub.
7. The starter has not been compiled in the authoring environment. GitHub Actions must complete successfully before treating the APK as build-verified. Review build logs if it fails.
8. This is a first functional MVP, not a Play Store-ready release. Quiz progress analytics, robust OCR, full Drive API integration, encrypted key storage, and automated tests are future hardening tasks.

## Build an APK using only your Android phone

### One-time GitHub setup

1. Create a **private** repository on GitHub, for example `StudlrTse`.
2. Download `StudlrTse-Android.zip` from this handover and upload that ZIP to the repository root. Keep the filename exactly `StudlrTse-Android.zip` and commit it to `main`.
3. Create a new repository file named exactly `.github/workflows/build-apk.yml`.
4. Copy the complete contents of the `GITHUB-WORKFLOW-BOOTSTRAP.yml` file supplied in this package into that new file and commit it to `main`.
5. Open the repository's **Actions** tab, select **Build StudlrTse APK**, and choose **Run workflow** if it has not started automatically.
6. Wait for a green check. Open the completed run, scroll to **Artifacts**, and download `StudlrTse-debug-apk`.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your Android phone. Android may ask you to allow your browser or file manager to install unknown apps.

The APK is a debug build for personal testing, not a signed Play Store release.

## Configure AI

1. Create an API key at https://openrouter.ai/keys.
2. Install and open StudlrTse.
3. Go to Settings, paste your key, and save.
4. The default model field is `openrouter/free`. OpenRouter's free model availability, limits, and terms can change; confirm the model is currently available to your account. You may replace it with another model ID available to your account.

AI providers receive the relevant document text included in your prompt. Do not submit confidential material unless you are comfortable with the provider's data-handling terms.

## Project structure

```text
StudlrTse/
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/studlrtse/app/MainActivity.kt
  app/src/main/res/drawable/ic_studlrtse.xml
  app/src/main/res/values/styles.xml
  app/build.gradle.kts
  build.gradle.kts
  settings.gradle.kts
  .github/workflows/build-apk.yml
```
